# Itertools Part 2

# Permutations: Order matters - some copies with same inputs but in different order

# Combinations: Order does not matter - no copies with same inputs