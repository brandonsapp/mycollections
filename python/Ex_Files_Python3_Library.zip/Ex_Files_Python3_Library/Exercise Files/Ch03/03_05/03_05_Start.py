# Iterative Files
myFile = open("scores.txt", "r")

# Read one line at a time

# Iterate through each line of a file