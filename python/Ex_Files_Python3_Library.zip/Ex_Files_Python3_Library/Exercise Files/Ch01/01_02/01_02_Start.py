# Python Comparison Operators

# TIPS:
# == --> is equal to
# <= --> is less than or equal to
# >= --> is greater than or equal to
# < --> is less than
# > --> is greater than



# < --> is less than

# == --> is equal to

# < --> is less than

#False --> 0
#True --> 1
# > --> is greater than

# Looking for first mismatched letter
# A - Z --> 1 - 26
# > --> is greater than

# A - Z --> 1 - 26
# <= --> is less than or equal to