# Python Comparison Operators

# TIPS:
# == --> is equal to
# <= --> is less than or equal to
# >= --> is greater than or equal to
# < --> is less than
# > --> is greater than



# < --> is less than
print(10 < 75)
print(75 < 10)

if 10 < 75:
    print("The bigger number is bigger")

# == --> is equal to
kitten = 10
tiger = 75

if kitten < tiger:
    print("The kitten weighs less than the tiger")

# < --> is less than
mouse = 1
if mouse < kitten and mouse < tiger:
    print("The mouse weighs the least")


#False --> 0
#True --> 1
# > --> is greater than
print(False > True)

# Looking for first mismatched letter
# A - Z --> 1 - 26
# > --> is greater than
print("Jennifer" > "Jenny")

# A - Z --> 1 - 26
# <= --> is less than or equal to
print('a' <= 'b')