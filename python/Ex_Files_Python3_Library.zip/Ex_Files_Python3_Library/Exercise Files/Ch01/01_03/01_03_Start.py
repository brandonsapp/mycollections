# Calculating Length

# len() --> returns length