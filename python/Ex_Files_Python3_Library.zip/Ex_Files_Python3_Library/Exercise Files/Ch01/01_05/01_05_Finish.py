# Minimum and Maximum

playerOneScore = 10
playerTwoScore = 4
print(min(playerOneScore, playerTwoScore))
print(min(0, 12, -19))

print(min("Kathryn", "Katie"))
print(min("Angela", "Bob"))

print(max(playerOneScore, playerTwoScore))
playerThreeScore = 14
print(max(playerThreeScore, playerTwoScore, playerOneScore))
print(max("Kathryn", "Katie"))