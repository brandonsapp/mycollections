# Python Logical Operators: And, Or, Not:

# What is a Boolean?

# Logical Operators -> Special Operators for Booleans

# AND
# true and true --> true
# false and true --> false
# true and false --> false
# false and false --> false

# OR
# true and true --> true
# false and true --> true
# true and false --> true
# false and false --> false

# NOT
# true --> false
# false --> true
