# Range -> range instance that holds all nums counting by one between 0 and first input
# List -> lists numbers from the inputted tuple
